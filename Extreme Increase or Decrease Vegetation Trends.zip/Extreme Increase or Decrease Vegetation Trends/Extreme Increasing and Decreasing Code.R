#Pick out a few sites to plot the yearly averages; get a feel for what the smooth data looks like
#Linear Regression
#Site 500
years <- 1:25
plot(years, yearly.avgs[500,], "l", ylim=c(200,700), xlab="1982 to 2006", ylab="NDVI Score", main="Average NDVI Values")
lm(as.numeric(yearly.avgs[500,]) ~ years)
abline(lm(as.numeric(yearly.avgs[500,]) ~ years), col="red")
summary(lm(as.numeric(yearly.avgs[500,]) ~ years))
#Site 226
years <- 1:25
plot(years, yearly.avgs[226,], "l", xlab="1982 to 2006", ylab="NDVI Score", main="Average NDVI Values")
lm(as.numeric(yearly.avgs[226,]) ~ years)
abline(lm(as.numeric(yearly.avgs[226,]) ~ years), col="red")
summary(lm(as.numeric(yearly.avgs[226,]) ~ years))
summary(lm(as.numeric(yearly.avgs[226,]) ~ years))$coefficients[2,4]#p-value only
sign(summary(lm(as.numeric(yearly.avgs[226,]) ~ years))$coefficients[2,1])#slope (sign of slope)
#Site 30881
years <- 1:25
plot(years, yearly.avgs[30880,], "l", xlab="1982 to 2006", ylab="NDVI Score", main="Average NDVI Values")
lm(as.numeric(yearly.avgs[30880,]) ~ years)
abline(lm(as.numeric(yearly.avgs[30880,]) ~ years), col="red")
summary(lm(as.numeric(yearly.avgs[30880,]) ~ years))
#Extract Slope and -pvalue
summary(lm(as.numeric(yearly.avgs[30880,]) ~ years))$coefficients
#Loop that grabs only slope and p-values
pvals <- c(rep(0, 49681))
slopes <- c(rep(0, 49681))
for(i in 1:49681){
  pvals[i] <- summary(lm(as.numeric(yearly.avgs[i,]) ~ years))$coefficients[2,4]
  slopes[i] <- sign(summary(lm(as.numeric(yearly.avgs[i,]) ~ years))$coefficients[2,1])
}
#Put info into a map
#if pvalue > 0.01 = tan indicationg no change in vegetation
#if pvalue < 0.01 & slope is positive = green indicating increase in changes
#if pvalue < 0.01 & slope is negative = red indicating decrease in changes
plot(xcoord, ycoord, pch=20, col="grey", main="Extreme Changes in NDVI", xlab= "Latitude", ylab= "Longitude")
inc.trend <- 0
dec.trend <- 0
no.trend <- 0
for(i in 1:49681){
  if(pvals[i] > 0.01){
    points(xcoord[i], ycoord[i], pch=20, col="tan")
    no.trend <- no.trend + 1
  }
  if(pvals[i] < 0.01 & slopes[i] == 1){
    points(xcoord[i], ycoord[i], pch=20, col="green")
    inc.trend <- inc.trend + 1
  }
  if(pvals[i] < 0.01 & slopes[i] == -1){
    points(xcoord[i], ycoord[i], pch=20, col="red")
    dec.trend <- dec.trend + 1
  }
}
#Mark selected site with increasing trend with X
points(xcoord[171], ycoord[171], pch="X", cex=2, col="darkgreen")
#Mark selected site with decreasing trend with X
points(xcoord[1323], ycoord[1323], pch="X", cex=2, col="darkred")
legend(x=40, y=-4, c("No NDVI change", "Inc. Trend", "Dec. Trend"), fill=c("tan", "green", "red"), cex = .5, box.lty = 0)
no.trend
inc.trend
dec.trend
slope.vals <- c(rep(0, 49681))
for(i in 1:49681){
  slope.vals[i] <- summary(lm(as.numeric(yearly.avgs[i,]) ~ years))$coefficients[2,1]
}
plot(slope.vals)
#Collect sites with decreasing pattern to pick sample for graph
dec.sites <- 0
for(i in 1:49681){
  if(pvals[i] < 0.01 & slope.vals[i] <= -5){
    dec.sites <- c(dec.sites,i)
  }
}
dec.sites
summary(lm(as.numeric(yearly.avgs[1323,]) ~ years))#$coefficients[2,1]
#Collect sites with incresing pattern to pick sample for graph
inc.sites <- 0
for(i in 1:49681){
  if(pvals[i] < 0.01 & slope.vals[i] >= 5){
    inc.sites <- c(inc.sites,i)
  }
}
inc.sites
summary(lm(as.numeric(yearly.avgs[171,]) ~ years))#$coefficients[2,1]
#Graph one example of a site with a increasing trend and one with decreasing trend in same window.
par(mfrow=c(2,1))
#Site 171 - Increasing Trend
years <- 1:25
plot(years, yearly.avgs[171,], "l", xlab="1982 to 2006", ylab="NDVI Score", main="Extreme Inc. Site N171")
lm(as.numeric(yearly.avgs[171,]) ~ years)
abline(lm(as.numeric(yearly.avgs[171,]) ~ years), col="red")
#Site 1323 - Decreasing Trend
years <- 1:25
plot(years, yearly.avgs[1323,], "l", xlab="1982 to 2006", ylab="NDVI Score", main="Extreme Dec. Site N1323")
lm(as.numeric(yearly.avgs[1323,]) ~ years)
abline(lm(as.numeric(yearly.avgs[1323,]) ~ years), col="red")