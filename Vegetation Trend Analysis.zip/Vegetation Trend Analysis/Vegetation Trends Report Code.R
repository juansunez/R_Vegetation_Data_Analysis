#Read Data
file1 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 1.txt", header = T)
file2 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 2.txt", header = T)
file3 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 3.txt", header = T)
file4 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 4.txt", header = T)
file5 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 5.txt", header = T)
file6 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 6.txt", header = T)
file7 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 7.txt", header = T)
file8 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 8.txt", header = T)
file9 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 9.txt", header = T)
file10 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 10.txt", header = T)
file11 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 11.txt", header = T)
file12 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 12.txt", header = T)
file13 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 13.txt", header = T)
file14 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 14.txt", header = T)
file15 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 15.txt", header = T)
file16 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 16.txt", header = T)
file17 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 17.txt", header = T)
file18 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 18.txt", header = T)
file19 <- read.table("C:/Users/jsunez/Desktop/DSS 665/Week 5/Data/Vegetation Data 19.txt", header = T)
#Merge Files
veg.data <- rbind(file1,file2,file3,file4,file5,file6,file7,file8,file9,file10,file11,file12,file13,file14,file15,file16,file17,file18,file19)
#dimensions
dim(veg.data)
head(veg.data)
#Site Variable
site <- veg.data[,1]
xcoord <- veg.data[,2]
ycoord <- veg.data[,3]
#Idea of what site data looks like (plot)
time.code <- 1:600
par(mfrow=c(3, 1))
plot(time.code, veg.data[500,4:603], ylim=c(0, 1000), ylab="NDVI Score", xlab="1982-2006", main = "Plot of Site N09506", "l") #Columns with NDVI values
plot(time.code, veg.data[24500,4:603], ylim=c(0, 1000), ylab="NDVI Score", xlab="1982-2006", main = "Plot of Site N37633", "l") 
plot(time.code, veg.data[49000,4:603], ylim=c(0, 1000), ylab="NDVI Score", xlab="1982-2006", main = "Plot of Site N08442", "l")
