#Mini Assignment 2
#Calculate avg. NDVI value for all sites
as.numeric(veg.data[1,4:603])
avg.NDVI <- rep(0, 49681)
#Rplc zeros with averages
for(i in 1:49681){
  avg.NDVI[i] <- mean(as.numeric(veg.data[i,4:603]))
}
#Map-out averages
veg.avgs <- cbind(xcoord, ycoord, avg.NDVI)
#Build Plot
win.graph()
plot(xcoord, ycoord, pch=20, col="tan", main = "Map of Avg. NDVI at Each Site", xlab = "Latitude", ylab = "Longitude")
for(i in 1:49681){
  if(avg.NDVI[i] < 200){
    points(xcoord[i], ycoord[i],pch=20, cex=.6, col="red")
  }
  if(avg.NDVI[i] > 200 & avg.NDVI[i] < 400){
    points(xcoord[i], ycoord[i],pch=20, cex=.6, col="tan")
  }
  if(avg.NDVI[i] > 400 & avg.NDVI[i] < 600){
    points(xcoord[i], ycoord[i],pch=20, cex=.6, col="lightgreen")
  }
  if(avg.NDVI[i] > 600 & avg.NDVI[i] < 700){
    points(xcoord[i], ycoord[i],pch=20, cex=.6, col="green")
  }
  if(avg.NDVI[i] > 700){
    points(xcoord[i], ycoord[i],pch=20, cex=.6, col="darkgreen")
  }
}
legend(x=39.5, y=-4, c("NDVI < 200", "200 < NDVI < 400", "400 < NDVI < 600", "600 < NDVI < 700", "NDVI>700"), fill=c("red", "tan", "lightgreen", "green", "darkgreen"), cex = .5, box.lty = 0)
